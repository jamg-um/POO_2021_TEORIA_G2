package pruebas;

import java.util.LinkedList;

import banco.Cuenta;
import banco.Utils;
import personal.Persona;

public class Programa {

	public static void main(String[] args) {
		Persona p = new Persona(01234567,"Antonio López");
		Cuenta cuenta1 = new Cuenta(p,300.0);
		Cuenta cuenta2 = new Cuenta(p, 300.0);
		System.out.println(Cuenta.SALDO_MINIMO);
		LinkedList<String> lista = new LinkedList<String>();
		
		int repeticiones = 5;
		Utils.extender(lista, "hola", repeticiones);
		Utils.extender(lista,"hola","hola","hola");
		System.out.println("lista = "+lista);
		System.out.println("repeticiones = "+repeticiones);
	}
}
