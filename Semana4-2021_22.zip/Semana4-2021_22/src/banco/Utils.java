package banco;

import java.util.LinkedList;

public class Utils {
	public static void extender(LinkedList<String> lista, String valor, int repeticiones) {
		for(int i=0;i<repeticiones;i++) {
			lista.add(valor);
		}
	}
	public static void extender(LinkedList<String> lista, String...valores) {
		for(String valor: valores) {
			lista.add(valor);
		}
	}
}
