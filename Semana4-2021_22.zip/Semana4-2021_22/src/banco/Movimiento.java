package banco;

import java.time.LocalDate;

public class Movimiento {
	//PROPIEDADES
	private final double cantidad;
	private final LocalDate fecha;
	//METODOS DE CONSULTA
	public double getCantidad() {
		return cantidad;
	}
	public LocalDate getFecha() {
		return fecha;
	}
	//CONSTRUCTOR
	public Movimiento(double cantidad) {
		this.cantidad = cantidad;
		fecha = LocalDate.now();
	}
}
