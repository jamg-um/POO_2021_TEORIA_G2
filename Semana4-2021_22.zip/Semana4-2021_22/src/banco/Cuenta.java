package banco;

import java.util.LinkedList;

import personal.Persona;

public class Cuenta {
	//CONSTANTES
	public static final double SALDO_MINIMO = -10;
	//PROPIEDADES
	private EstadoCuenta estado;
	private double saldo;
	private final Persona titular;
	private LinkedList<Movimiento> ultimasOperaciones;
	//METODOS DE CONSULTA Y ESTABLECIMIENTO
	public double getSaldo() {
		return saldo;
	}
	public Persona getTitular() {
		return titular;
	}
	public EstadoCuenta getEstado() {
		return estado;
	}
	public LinkedList<Movimiento> getUltimasOperaciones() {
		return new LinkedList<Movimiento>(ultimasOperaciones);
	}	
	//CONSTRUCTORES
	public Cuenta(Persona titular, double saldo) {
		this.saldo		= saldo;
		this.titular	= titular;
		estado = EstadoCuenta.OPERATIVA;
		ultimasOperaciones = new LinkedList<Movimiento>();
		anotarMovimientos(saldo);
		titular.addCuenta(this);
	}
	public Cuenta(Persona titular) {
		this(titular,0);
	}
	public Cuenta(Cuenta cuenta) {
		this(cuenta.getTitular(),cuenta.getSaldo());
	}
	//FUNCIONALIDAD
	public void ingreso(double cantidad) {
		saldo +=cantidad;
		anotarMovimientos(cantidad);
	}	
	public void reintegro(double cantidad) {
		if(saldo-cantidad >= 0) {
			saldo -=cantidad;
			anotarMovimientos(-1*cantidad);
		}
	}	
	private void anotarMovimientos(double cantidad) {
		Movimiento mov = new Movimiento(cantidad);
		ultimasOperaciones.addFirst(mov);
	}
}
