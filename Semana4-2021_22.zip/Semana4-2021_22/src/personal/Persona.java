package personal;
import java.util.LinkedList;

import banco.Cuenta;
public class Persona {
	//PROPIEDADES
	private LinkedList<Cuenta> listaCuentas;
	private final int dni;
	private final String nombre;
	//METODOS CONSULTA
	public int getDni() {
		return dni;
	}
	public String getNombre() {
		return nombre;
	}
	public LinkedList<Cuenta> getListaCuentas(){
		return new LinkedList<Cuenta>(listaCuentas);
	}
	//CONSTRUCTORES
	public Persona(int dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
		listaCuentas = new LinkedList<Cuenta>();
	}
	public Persona(Persona p) {
		this(p.getDni(),p.getNombre());
	}
	//FUNCIONALIDAD
	public void addCuenta(Cuenta cuenta) {
		listaCuentas.add(cuenta);
	}
}
