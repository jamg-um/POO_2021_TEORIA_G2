package prueba;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import eventos.Evento;
import eventos.EventoLibre;
import eventos.EventoRestringido;
import eventos.Marcador;

public class Programa {

	public static void main(String[] args) {
		EventoLibre el = new EventoLibre("Real Madrid - F.C. Barcelona",1);
		el.apostar("Juan", new Marcador(5,0));
		el.apostar("pepe", new Marcador(1,3));
		
		EventoRestringido er = new EventoRestringido("Nadal vs Federer", 3, new Marcador(2,0), new Marcador(2,1), new Marcador(0,2), new Marcador(1,2));
		er.apostar("Juan", new Marcador(2,0));
		er.apostar("pedro", new Marcador(2,1));
		er.apostar("pepe", new Marcador(2,0));
		
		List<Evento> lista = new ArrayList<Evento>(2);
		Collections.addAll(lista, el,er);
		
		for(Evento e: lista) {
			boolean apostado = e.apostar("enrique", new Marcador(5,0));
			
			if(apostado) {
				System.out.println("Enrique ha podido realizar la apuesta (5,0) en el evento "+e.getNombre());	
			}else {
				System.out.println("Enrique no ha podido realizar la apuesta (5,0) en el evento "+e.getNombre());
			}
		}
		
		for(Evento e: lista) {
			System.out.println(e);
		}
		
		for(Evento e: lista) {
			if(e instanceof EventoRestringido) {
				int numeroApuestas = ((EventoRestringido) e).getNumeroApuestas(new Marcador(2,0));
				System.out.println("El n�mero de apuestas en el evento "+e.getNombre()+" para el marcador (2,0) es "+numeroApuestas);
			}
		}
	}

}
