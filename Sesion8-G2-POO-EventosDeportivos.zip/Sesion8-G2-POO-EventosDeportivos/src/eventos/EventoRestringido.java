package eventos;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class EventoRestringido extends Evento {
	//PROPIEDADES
	private final Set<Marcador> opciones;
	//METODOS CONSULTA
	public Set<Marcador> getOpciones() {
		return new HashSet<Marcador>(opciones);
	}
	//CONSTRUCTORES
	public EventoRestringido(String nombre, double precioApuesta, Marcador...marcadores /*Set<Marcador> opciones*/) {
		super(nombre, precioApuesta);
		this.opciones = new HashSet<Marcador>();
		Collections.addAll(opciones,marcadores);
		//this.opciones = new HashSet<Marcador>(opciones);
	}
	//FUNCIONALIDAD
	public int getNumeroApuestas(Marcador marcador) {
		int numeroApuestas = 0;
		for(Marcador value: getMapaApuestas().values()) {
			if(value.equals(marcador)) numeroApuestas++;
		}
		return numeroApuestas;
	}
	@Override
	protected boolean esAceptable(Marcador marcador) {
		return opciones.contains(marcador);
	}
	@Override
	public String toString() {
		return super.toString()+" [opciones=" + opciones + "]";
	}
	
}
