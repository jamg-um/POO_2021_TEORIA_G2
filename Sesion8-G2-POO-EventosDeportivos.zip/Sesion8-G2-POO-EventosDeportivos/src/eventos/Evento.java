package eventos;

import java.util.HashMap;
import java.util.Map;

public abstract class Evento {
	//PROPIEDADES
	private String nombre;
	private final double precio;
	private Map<String,Marcador> mapaApuestas;
	//numeroApuestas propiedad calculada
	//recaudacion propiedad calculada
	
	//M�todos de consulta
	public String getNombre() {
		return nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public Map<String, Marcador> getMapaApuestas() {
		Map<String, Marcador> mapa  =  new HashMap<String,Marcador>(mapaApuestas);
		return mapa;
	}
	public int getNumeroApuestas(){
		return mapaApuestas.size();
	}
	public double getRecaudacion(){
		return getNumeroApuestas()*precio;
	}
	//CONSTRUCTOR
	public Evento(String nombre, double precioApuesta){
		this.nombre = nombre;
		this.precio = precioApuesta;
		mapaApuestas = new HashMap<String,Marcador>();
	}
	//FUNCIONALIDAD
	public boolean apostar(String usuario, Marcador marcador){
		if(esAceptable(marcador)){
			mapaApuestas.put(usuario,marcador);
			return true;
		}
		return false;
	}
	protected abstract boolean esAceptable(Marcador marcador);
	
	@Override
	public String toString() {
		return getClass().getName()+" [nombre=" + nombre + ", precio=" + precio
				+ ", mapaApuestas=" + mapaApuestas + ", getNumeroApuestas()="
				+ getNumeroApuestas() + ", getRecaudacion()="
				+ getRecaudacion() + "]";
	}
	
	
}
