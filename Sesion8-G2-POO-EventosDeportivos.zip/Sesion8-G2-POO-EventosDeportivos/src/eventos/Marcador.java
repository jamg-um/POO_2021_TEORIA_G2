package eventos;

import java.util.Objects;

public class Marcador {
	//PROPIEDADES
	private final int tanteoLocal;
	private final int tanteoVisitante;
	//M�todos consulta
	public int getTanteoLocal() {
		return tanteoLocal;
	}
	public int getTanteoVisitante() {
		return tanteoVisitante;
	}
	//CONSTRUCTORES
	public Marcador(int tanteoLocal, int tanteoVisitante){
		this.tanteoLocal = tanteoLocal;
		this.tanteoVisitante = tanteoVisitante;
	}
	//FUNCIONALIDAD
	@Override
	public int hashCode() {
		/*
		final int prime = 31;
		int result = 1;
		result = prime * result + tanteoLocal;
		result = prime * result + tanteoVisitante;
		return result;
		//0 - 1  => hashcode = 31*31+1
		//1 - 0  => hashCode = 31*32+0
		 */
		
		return Objects.hash(tanteoLocal,tanteoVisitante);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Marcador other = (Marcador) obj;
		if (tanteoLocal != other.tanteoLocal)
			return false;
		if (tanteoVisitante != other.tanteoVisitante)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return getClass().getName()+" [tanteoLocal=" + tanteoLocal + ", tanteoVisitante="
				+ tanteoVisitante + "]";
	}
}
