package eventos;

public class EventoLibre extends Evento {

	public EventoLibre(String nombre, double precioApuesta) {
		super(nombre, precioApuesta);
	}

	@Override
	protected boolean esAceptable(Marcador marcador) {
		return !(getMapaApuestas().values().contains(marcador));
	}

}
