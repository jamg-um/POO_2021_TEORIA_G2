package pruebas;

import banco.Cuenta;
import personal.Persona;

public class Programa {

	public static void main(String[] args) {
		Persona p = new Persona(01234567,"Antonio López");
		Cuenta cuenta1 = new Cuenta(p, 300.0);
		Cuenta cuenta2 = new Cuenta(p, 300.0);
		System.out.println(cuenta1 == cuenta2);
	}
}
