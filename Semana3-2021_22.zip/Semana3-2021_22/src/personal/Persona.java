package personal;

public class Persona {
	//PROPIEDADES
	private int dni;
	private String nombre;
	//METODOS CONSULTA
	public int getDni() {
		return dni;
	}
	public String getNombre() {
		return nombre;
	}
	//CONSTRUCTORES
	public Persona(int dni, String nombre) {
		this.dni = dni;
		this.nombre = nombre;
	}
	//FUNCIONALIDAD
}
