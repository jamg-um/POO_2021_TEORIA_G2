package banco;

public enum EstadoCuenta {
	OPERATIVA, INMOVILIZADA, NUMEROS_ROJOS;
}
