package pruebas;

import geometria.Circulo;
import geometria.Direccion;
import geometria.Figura;
import geometria.Punto;
import geometria.PuntoColor;

public class PruebaCirculo {

	public static void main(String[] args) {
		Punto punto1 = new Punto(2,3);
		Circulo circulo1 = new Circulo(punto1,3);
		Circulo circulo2 = new Circulo();
		System.out.println("Circulo 2 -> centro = ("+circulo2.getCentro().getX()+","
					+ circulo2.getCentro().getY()+"); radio = "+circulo2.getRadio());
		Circulo circulo3 = new Circulo(circulo1);
		System.out.println("Circulo 3 -> centro = ("+circulo3.getCentro().getX()+","
				+ circulo3.getCentro().getY()+"); radio = "+circulo3.getRadio());
	
		
		circulo1.desplazar(3, 2);
		System.out.println("Circulo 1 -> centro = ("+circulo1.getCentro().getX()+","
				+ circulo1.getCentro().getY()+"); radio = "+circulo1.getRadio());
	
		circulo2.escalar(150);
		System.out.println("Circulo 2 escalado -> centro = ("+circulo2.getCentro().getX()+","
				+ circulo2.getCentro().getY()+"); radio = "+circulo2.getRadio());
		Punto punto2 = circulo3.getCentro();
		
		circulo2.desplazar(5, Direccion.ARRIBA);
	}

}
