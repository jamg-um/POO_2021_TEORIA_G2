package geometria;

public enum Direccion {
	ARRIBA, ABAJO, DERECHA, IZQUIERDA
}
