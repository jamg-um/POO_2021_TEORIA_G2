package geometria;

public class PuntoColor extends Punto {
	public PuntoColor(){
		super(0,0);
	}
	//private int codigoColor;
	
	/*@Override
	public String toString() {
		return super.toString()+"[codigoColor="+codigoColor+"]";
	}*/
	
	@Override
	public PuntoColor clone(){
		PuntoColor pc = (PuntoColor)super.clone();
		return pc;
	}	
}
