package geometria;

import java.awt.Color;

public abstract class Figura {
	private Color color;
	public Figura(){
		this.color = null;
	}
	public Color getColor(){
		return color;
	}
	public void setColor(Color color){
		this.color = color;
	}
	public abstract double getPerimetro();
	public abstract void desplazar(int coorX, int coorY);
	public void desplazar(int cantidad, Direccion direccion){
		int coorX = 0;
		int coorY = 0;
	
		switch(direccion) {
		case ARRIBA:
			coorY = cantidad;
			break;
		case ABAJO:
			coorY = -cantidad;
			break;
		case DERECHA:
			coorX = cantidad;
			break;
		case IZQUIERDA:
			coorX = -cantidad;
			break;
		default:
			System.out.println("No es una dirección correcta");
		}
		desplazar(coorX,coorY);
	}
}
