package geometria;

public class Circulo extends Figura implements Cloneable {
	//PROPIEDADES
	private Punto centro;
	private int	radio;
	//METODOS CONSULTA
	public Punto getCentro() {
		return new Punto(centro);
	}
	public int getRadio() {
		return radio;
	}
	public double getPerimetro() {//PROPIEDAD CALCULADA
		return 2*Math.PI*radio;
	}
	//CONSTRUCTOR
	public Circulo(Punto centro, int radio) {
		this.centro = centro;
		this.radio = radio;
	}
	public Circulo() {
		this(new Punto(),5);
	}
	public Circulo(Circulo circulo) {
		this(circulo.getCentro(),circulo.getRadio());
	}
	//FUNCIONALIDAD
	public void desplazar(int coorX, int coorY) {
		centro.desplazar(coorX, coorY);
	}
	public void escalar(int porcentaje) {
		radio *=(porcentaje/100.0);
	}
	@Override
	public Circulo clone(){
		Circulo copiaSuperficial = copiaSuperficial();
		Circulo copia = copiaSuperficial;
		copia.centro = centro.clone();
		return copia;
	}
	
	private Circulo copiaSuperficial(){
		try{
			Circulo copiaSuperficial = (Circulo) super.clone();
			return  copiaSuperficial;
		}catch(CloneNotSupportedException cnse){
			return null;
		}
	}
}
