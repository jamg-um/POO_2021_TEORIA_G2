package geometria;

public class Rectangulo extends Figura{
	//PROPIEDADES
	private Punto verticeII;
	private int ladoX;
	private int ladoY;
	//METODOS CONSULTA
	public Punto getVerticeII() {
		return new Punto(verticeII);
	}
	public Punto getVerticeSI() {//PROPIEDAD CALCULADA
		return new Punto(verticeII.getX(),verticeII.getY()+ladoY);
	}
	public Punto getVerticeID()	{//PROPIEDAD CALCULADA
		return new Punto(verticeII.getX()+ladoX, verticeII.getY());
	}
	public Punto getVerticeSD() {//PROPIEDAD CALCULADA
		return new Punto(verticeII.getX()+ladoX, verticeII.getY()+ladoY);
	}
	public int getLadoX() {
		return ladoX;
	}
	public int getLadoY() {
		return ladoY;
	}
	//CONSTRUCTORES
	public Rectangulo(Punto verticeII, int ladoX, int ladoY) {
		this.verticeII = verticeII;
		this.ladoX = ladoX;
		this.ladoY = ladoY;
	}
	public Rectangulo(Punto verticeII,Punto verticeSD) {
		this(verticeII,verticeSD.getX()-verticeII.getX(),verticeSD.getY()-verticeII.getY());
	}
	//FUNCIONALIDAD
	public void desplazar(int coorX, int coorY) {
		verticeII.desplazar(coorX, coorY);
	}
	public void escalar(int porcentaje) {
		ladoX *= (porcentaje/100.0);
		ladoY *= (porcentaje/100.0);
	}
	@Override
	public double getPerimetro() {
		return (getLadoX()*2.0+getLadoY()*2.0);
	}
}
