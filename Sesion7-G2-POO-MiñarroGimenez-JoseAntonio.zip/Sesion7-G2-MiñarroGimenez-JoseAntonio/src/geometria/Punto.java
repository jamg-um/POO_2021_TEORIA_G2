package geometria;

import java.util.Objects;

public class Punto implements Cloneable{
	//PROPIEDADES
	private int x;
	private int y;
	//METODOS CONSULTA
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	//CONSTRUCTOR
	public Punto(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public Punto() {
		this(0,0);
	}
	public Punto(Punto punto) {
		this(punto.getX(),punto.getY());
	}
	
	//FUNCIONALIDAD
	public void desplazar(int coorX, int coorY) {
		x+=coorX;
		y+=coorY;
	}	
	public void desplazar(Direccion direccion) {
		int coorX = 0;
		int coorY = 0;
	
		switch(direccion) {
		case ARRIBA:
			coorY = 1;
			break;
		case ABAJO:
			coorY = -1;
			break;
		case DERECHA:
			coorX = 1;
			break;
		case IZQUIERDA:
			coorX = -1;
			break;
		default:
			System.out.println("No es una dirección correcta");
		}
		desplazar(coorX,coorY);
	}
	@Override
	public int hashCode() {
		return Objects.hash(x,y);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Punto other = (Punto) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return getClass().getName()+" [x=" + x + ", y=" + y + "]";
	}
	
	@Override
	public Punto clone(){
		Punto copia = copiaSuperficial();
		return copia;
	}
	
	private Punto copiaSuperficial(){
		try{
			Punto copiaSuperficial = (Punto) super.clone();
			return  copiaSuperficial;
		}catch(CloneNotSupportedException cnse){
			return null;
		}
	}
}
